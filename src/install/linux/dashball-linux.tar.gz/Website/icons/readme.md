# Icons
This folder contains the icons for the applications page.

# Add a icon
To add a icon to a process you can save the icon in this folder as {processname}.png

That's all 

You don't have to worry about the pixel size. The icon will display with a width and height of 20px



